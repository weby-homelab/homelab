#!/bin/bash
echo 'Deploying Kubernetes cluster...'