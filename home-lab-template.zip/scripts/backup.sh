#!/bin/bash
DATE=$(date +%F)
tar -czf /backups/home-lab-$DATE.tar.gz /etc /home
echo "Backup created: /backups/home-lab-$DATE.tar.gz"
